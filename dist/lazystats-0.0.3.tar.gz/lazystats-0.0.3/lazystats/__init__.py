from .Randnums import LCG

__all__ = [
    "LCS",
]
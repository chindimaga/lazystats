This library has basic mathematical implementations which can increase your working pace

## To install 
> pip install lazystats
## How to use 

> import lazystats
> a = lazystats.Randnums.LCG(10,100)
> a.generate()


This is a basic library for probab dists
